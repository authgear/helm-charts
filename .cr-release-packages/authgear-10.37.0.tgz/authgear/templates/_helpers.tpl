{{/*
Expand the name of the chart.
*/}}
{{- define "authgear.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "authgear.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "authgear.labels" -}}
helm.sh/chart: {{ include "authgear.chart" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{- define "authgear.nameMain" -}}
{{- printf "%s-%s" .Release.Name "main" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "authgear.mainSelectorLabels" -}}
app.kubernetes.io/name: {{ include "authgear.nameMain" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{- define "authgear.nameAdmin" -}}
{{- printf "%s-%s" .Release.Name "admin" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "authgear.adminSelectorLabels" -}}
app.kubernetes.io/name: {{ include "authgear.nameAdmin" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{- define "authgear.nameResolver" -}}
{{- printf "%s-%s" .Release.Name "resolver" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "authgear.resolverSelectorLabels" -}}
app.kubernetes.io/name: {{ include "authgear.nameResolver" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{- define "authgear.nameImages" -}}
{{- printf "%s-%s" .Release.Name "images" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "authgear.imagesSelectorLabels" -}}
app.kubernetes.io/name: {{ include "authgear.nameImages" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{- define "authgear.namePortal" -}}
{{- printf "%s-%s" .Release.Name "portal" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "authgear.namePortalAuthgear" -}}
{{- printf "%s-%s" .Release.Name "portal-authgear" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "authgear.portalSelectorLabels" -}}
app.kubernetes.io/name: {{ include "authgear.namePortal" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{- define "authgear.nameSiteadmin" -}}
{{- printf "%s-%s" .Release.Name "siteadmin" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "authgear.siteadminSelectorLabels" -}}
app.kubernetes.io/name: {{ include "authgear.nameSiteadmin" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{- define "authgear.nameSiteadminPortal" -}}
{{- printf "%s-%s" .Release.Name "siteadmin-portal" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "authgear.siteadminPortalSelectorLabels" -}}
app.kubernetes.io/name: {{ include "authgear.nameSiteadminPortal" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{- define "authgear.siteadminHost" -}}
{{- if .Values.authgear.siteadminServer.host }}
{{- .Values.authgear.siteadminServer.host }}
{{- else }}
{{- printf "siteadmin.%s" .Values.authgear.defaultDomain }}
{{- end }}
{{- end }}

{{- define "authgear.nameUsageRecordCron" -}}
{{- printf "%s-%s" .Release.Name "usage-record-cron" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "authgear.nameUploadStripeCron" -}}
{{- printf "%s-%s" .Release.Name "upload-stripe" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "authgear.namePosthogGroupCron" -}}
{{- printf "%s-%s" .Release.Name "posthog-group-cron" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "authgear.namePosthogUserCron" -}}
{{- printf "%s-%s" .Release.Name "posthog-user-cron" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "authgear.nameAuditLogCron" -}}
{{- printf "%s-%s" .Release.Name "audit-log-cron" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "authgear.nameAnalyticCronHourly" -}}
{{- printf "%s-%s" .Release.Name "analytic-cron-hourly" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "authgear.nameAnalyticCronWeekly" -}}
{{- printf "%s-%s" .Release.Name "analytic-cron-weekly" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "authgear.nameAnalyticCronMonthly" -}}
{{- printf "%s-%s" .Release.Name "analytic-cron-monthly" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "authgear.nameAnalyticCronDaily" -}}
{{- printf "%s-%s" .Release.Name "analytic-cron-daily" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "authgear.nameAnalyticCronHourlyScript" -}}
{{- printf "%s-%s" .Release.Name "analytic-cron-hourly-script" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "authgear.nameAnalyticCronWeeklyScript" -}}
{{- printf "%s-%s" .Release.Name "analytic-cron-weekly-script" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "authgear.nameAnalyticCronMonthlyScript" -}}
{{- printf "%s-%s" .Release.Name "analytic-cron-monthly-script" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "authgear.nameAnalyticCronDailyScript" -}}
{{- printf "%s-%s" .Release.Name "analytic-cron-daily-script" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "authgear.nameBackground" -}}
{{- printf "%s-%s" .Release.Name "background" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "authgear.nameRedisAutoRewriteAOFCron" -}}
{{- printf "%s-%s" .Release.Name "redis-cron-rewriteaof" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "authgear.backgroundSelectorLabels" -}}
app.kubernetes.io/name: {{ include "authgear.nameBackground" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{- define "authgear.nameDeno" -}}
{{- printf "%s-%s" .Release.Name "deno" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "authgear.denoSelectorLabels" -}}
app.kubernetes.io/name: {{ include "authgear.nameDeno" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{- define "authgear.nameIngressTemplate" -}}
{{- printf "%s-%s" .Release.Name "ingress-template" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
The ingress controllers to render the Ingresses for, as YAML
{"controllers": [{name, class, annotations, ingressNamePrefix?}]}.
Without authgear.ingress.controllers, it is one controller named "nginx" with authgear.ingress.class and
authgear.ingress.annotations, which renders the same Ingresses as before the list existed.
*/}}
{{- define "authgear.ingressControllers" -}}
{{- $controllers := .Values.authgear.ingress.controllers -}}
{{- if empty $controllers -}}
{{- /* Not validated, so that existing values render exactly as before. */ -}}
{{- $controllers = list (dict "name" "nginx" "class" .Values.authgear.ingress.class "annotations" .Values.authgear.ingress.annotations) -}}
{{- else -}}
{{- include "authgear.validateIngressControllers" (dict "controllers" $controllers "path" "authgear.ingress.controllers" "customDomain" false) -}}
{{- end -}}
{{- toYaml (dict "controllers" $controllers) -}}
{{- end }}

{{/*
The ingress controllers to render the Ingresses of custom domains (ingress.tpl.yaml) for, as YAML
{"controllers": [{name, class, annotations, tlsSecretNameTemplate?}]}.
authgear.ingress.customDomain.controllers, or the same as "authgear.ingressControllers" when it is empty.
*/}}
{{- define "authgear.customDomainIngressControllers" -}}
{{- $controllers := (.Values.authgear.ingress.customDomain | default dict).controllers -}}
{{- if empty $controllers -}}
{{- include "authgear.ingressControllers" . -}}
{{- else -}}
{{- include "authgear.validateIngressControllers" (dict "controllers" $controllers "path" "authgear.ingress.customDomain.controllers" "customDomain" true) -}}
{{- toYaml (dict "controllers" $controllers) -}}
{{- end -}}
{{- end }}

{{/*
Fails on an invalid list of ingress controllers. Renders nothing.
Takes a dict with "controllers", "path" (of the values, for the messages) and "customDomain" (true for
authgear.ingress.customDomain.controllers, whose Ingresses are always named "<name>-<host>").
*/}}
{{- define "authgear.validateIngressControllers" -}}
{{- $path := .path -}}
{{- $customDomain := .customDomain -}}
{{- $names := dict -}}
{{- $prefixes := dict -}}
{{- range $index, $controller := .controllers -}}
{{- if empty .name -}}
{{- fail (printf "%s: every entry needs a name" $path) -}}
{{- end -}}
{{- /* The name is part of the Ingress names, which must be DNS subdomains. */ -}}
{{- if not (regexMatch "^[a-z0-9]([-a-z0-9]*[a-z0-9])?$" .name) -}}
{{- fail (printf "%s: %s must consist of lowercase letters, digits and '-'" $path .name) -}}
{{- end -}}
{{- if empty .class -}}
{{- fail (printf "%s: %s needs a class" $path .name) -}}
{{- end -}}
{{- if hasKey $names .name -}}
{{- fail (printf "%s: %s is listed more than once" $path .name) -}}
{{- end -}}
{{- $_ := set $names .name true -}}
{{- if $customDomain -}}
{{- if hasKey . "ingressNamePrefix" -}}
{{- fail (printf "%s: %s sets ingressNamePrefix, but the Ingresses of custom domains are always named \"<name>-<host>\"" $path .name) -}}
{{- end -}}
{{- if hasKey . "tlsSecretNameTemplate" -}}
{{- if not (kindIs "string" .tlsSecretNameTemplate) -}}
{{- fail (printf "%s: tlsSecretNameTemplate of %s must be a string" $path .name) -}}
{{- end -}}
{{- end -}}
{{- else -}}
{{- if hasKey . "tlsSecretNameTemplate" -}}
{{- fail (printf "%s: %s sets tlsSecretNameTemplate, but it only applies to authgear.ingress.customDomain.controllers" $path .name) -}}
{{- end -}}
{{- if hasKey . "ingressNamePrefix" -}}
{{- /* Empty is allowed: no prefix. Otherwise the start of a DNS subdomain, e.g. "traefik-". */ -}}
{{- /* Two ifs: "and" does not short-circuit in older Helm versions, and regexMatch fails on a non-string. */ -}}
{{- if not (kindIs "string" .ingressNamePrefix) -}}
{{- fail (printf "%s: ingressNamePrefix of %s must be a string" $path .name) -}}
{{- end -}}
{{- if not (regexMatch "^([a-z0-9][-a-z0-9]*)?$" .ingressNamePrefix) -}}
{{- fail (printf "%s: ingressNamePrefix of %s must be empty or start with a lowercase letter or digit, followed by lowercase letters, digits and '-'" $path .name) -}}
{{- end -}}
{{- end -}}
{{- /* Two controllers with the same prefix would render Ingresses with the same names. */ -}}
{{- $prefix := include "authgear.ingressNameForController" (dict "index" $index "controller" . "name" "") -}}
{{- if hasKey $prefixes $prefix -}}
{{- fail (printf "%s: %s and %s have the same Ingress name prefix %q" $path (get $prefixes $prefix) .name $prefix) -}}
{{- end -}}
{{- $_ := set $prefixes $prefix .name -}}
{{- end -}}
{{- end -}}
{{- end }}

{{/*
The name of an Ingress for a controller: ingressNamePrefix of the controller followed by the name, if the
controller sets it. Otherwise the first controller keeps the name, so that the existing Ingresses are updated in
place, and the others prefix it with "<controller name>-".
Takes a dict with "index" (of the controller), "controller" and "name".
*/}}
{{- define "authgear.ingressNameForController" -}}
{{- if hasKey .controller "ingressNamePrefix" -}}
{{- printf "%s%s" .controller.ingressNamePrefix .name -}}
{{- else if eq (int .index) 0 -}}
{{- .name -}}
{{- else -}}
{{- printf "%s-%s" .controller.name .name -}}
{{- end -}}
{{- end }}

{{- define "authgear.authgearSecretsYAML" -}}
secrets:
- key: db
  data:
    database_schema: {{ .authgear.databaseSchema | quote }}
    database_url: {{ .authgear.databaseURL | quote }}
- key: audit.db
  data:
    database_schema: {{ .authgear.auditLog.databaseSchema | quote }}
    database_url: {{ .authgear.auditLog.databaseURL | quote }}
- key: redis
  data:
    redis_url: {{ .authgear.redisURL | quote }}
{{- if .authgear.analytic.enabled }}
- key: analytic.redis
  data:
    redis_url: {{ .authgear.analytic.redisURL | quote }}
{{- end }}
- key: mail.smtp
  data:
    host: {{ .authgear.smtp.host | quote }}
    port: {{ .authgear.smtp.port }}
    mode: {{ .authgear.smtp.mode | quote }}
    username: {{ .authgear.smtp.username | quote }}
    password: {{ .authgear.smtp.password | quote }}
{{- if .authgear.twilio.accountSID }}
- key: sms.twilio
  data:
    account_sid: {{ .authgear.twilio.accountSID | quote }}
    auth_token: {{ .authgear.twilio.authToken | quote }}
{{- if .authgear.twilio.messageServiceID }}
    message_service_sid: {{ .authgear.twilio.messageServiceID | quote }}
{{- end }}
{{- end }}
{{- if .authgear.nexmo.apiKey }}
- key: sms.nexmo
  data:
    api_key: {{ .authgear.nexmo.apiKey | quote }}
    api_secret: {{ .authgear.nexmo.apiSecret | quote }}
{{- end }}
{{- if .authgear.elasticsearch.enabled }}
- key: elasticsearch
  data:
    elasticsearch_url: {{ .authgear.elasticsearch.url | quote }}
{{- end }}
{{- if .authgear.postgresqlsearch.enabled }}
- key: search.db
  data:
    database_schema: {{ .authgear.postgresqlsearch.databaseSchema | quote }}
    database_url: {{ .authgear.postgresqlsearch.databaseURL | quote }}
{{- end }}
{{- if .authgear.whatsappWATI.enabled }}
- key: whatsapp.wati
  data:
    whatsapp_phone_number: {{ .authgear.whatsappWATI.whatsappPhoneNumber | quote }}
    webhook_auth: {{ .authgear.whatsappWATI.webhookAuth | quote }}
{{- end }}
{{- if .authgear.whatsappOnPremises.enabled }}
- key: whatsapp.on-premises
  data:
    api_endpoint: {{ .authgear.whatsappOnPremises.apiEndpoint | quote }}
    username: {{ .authgear.whatsappOnPremises.username | quote }}
    password: {{ .authgear.whatsappOnPremises.password | quote }}
    templates:
      otp:
        {{- toYaml .authgear.whatsappOnPremises.authenticationTemplate | nindent 8 }}
{{- end}}
{{- if .authgear.whatsappCloudAPI.enabled }}
- key: whatsapp.cloud-api
  data:
    phone_number_id: {{ .authgear.whatsappCloudAPI.phoneNumberID | quote }}
    access_token: {{ .authgear.whatsappCloudAPI.accessToken | quote }}
    authentication_template:
      type: {{ .authgear.whatsappCloudAPI.authenticationTemplate.type | quote }}
      copy_code_button:
        name: {{ .authgear.whatsappCloudAPI.authenticationTemplate.copyCodeButton.name | quote }}
        languages:
{{ toYaml .authgear.whatsappCloudAPI.authenticationTemplate.copyCodeButton.languages | indent 10 }}
    webhook:
      verify_token: {{ .authgear.whatsappCloudAPI.webhook.verifyToken | quote }}
      app_secret: {{ .authgear.whatsappCloudAPI.webhook.appSecret | quote }}
{{- end }}
{{- if .authgear.oauthDemoSecrets.enabled }}
- key: sso.oauth.demo_credentials
  data:
    items:
      {{- toYaml .authgear.oauthDemoSecrets.items | nindent 6 }}
{{- end }}
{{- end }}

{{- define "authgear.portalHost" -}}
{{- if .Values.authgear.portalServer.host }}
{{- .Values.authgear.portalServer.host }}
{{- else }}
{{- printf "portal.%s" .Values.authgear.defaultDomain }}
{{- end }}
{{- end }}

{{/*
OpenTelemetry (metrics and traces) environment variables
*/}}
{{- define "authgear.otelEnv" -}}
{{- if .Values.authgear.otel.serviceName }}
- name: OTEL_SERVICE_NAME
  value: {{ .Values.authgear.otel.serviceName | quote }}
{{- end }}
{{- if .Values.authgear.metrics.otlp.enabled }}
- name: OTEL_METRICS_EXPORTER
  value: "otlp"
- name: OTEL_EXPORTER_OTLP_METRICS_ENDPOINT
  value: {{ .Values.authgear.metrics.otlp.endpoint | quote }}
{{- if .Values.authgear.metrics.otlp.exportInterval }}
- name: OTEL_METRIC_EXPORT_INTERVAL
  value: {{ .Values.authgear.metrics.otlp.exportInterval | quote }}
{{- end }}
{{- end }}
{{- if .Values.authgear.traces.otlp.enabled }}
- name: OTEL_TRACES_EXPORTER
  value: "otlp"
- name: OTEL_EXPORTER_OTLP_TRACES_ENDPOINT
  value: {{ .Values.authgear.traces.otlp.endpoint | quote }}
{{- end }}
{{- end }}

{{/*
Logging environment variables
*/}}
{{- define "authgear.searchEnv" -}}
{{- $impl := .Values.authgear.searchImplementation -}}
{{- if not $impl -}}
{{- if .Values.authgear.elasticsearch.enabled -}}
{{- $impl = "elasticsearch" -}}
{{- else if .Values.authgear.postgresqlsearch.enabled -}}
{{- $impl = "postgresql" -}}
{{- else -}}
{{- $impl = "none" -}}
{{- end -}}
{{- end -}}
{{- if .Values.authgear.postgresqlsearch.enabled }}
- name: SEARCH_DATABASE_URL
  value: {{ .Values.authgear.postgresqlsearch.databaseURL | quote }}
- name: SEARCH_DATABASE_SCHEMA
  value: {{ .Values.authgear.postgresqlsearch.databaseSchema | quote }}
{{- end }}
- name: SEARCH_IMPLEMENTATION
  value: {{ $impl | quote }}
{{- end }}

{{/*
Source map (*.map) serving environment variables
*/}}
{{- define "authgear.sourceMapEnv" -}}
- name: SOURCE_MAP_ENABLED
  value: {{ .Values.authgear.sourceMap.enabled | quote }}
{{- if .Values.authgear.sourceMap.sentryToken }}
- name: SOURCE_MAP_SENTRY_TOKEN
  value: {{ .Values.authgear.sourceMap.sentryToken | quote }}
{{- end }}
{{- end }}

{{- define "authgear.analyticPosthogEnv" -}}
{{- if .Values.authgear.analytic.posthog.endpoint }}
- name: ANALYTIC_POSTHOG_ENDPOINT
  value: {{ .Values.authgear.analytic.posthog.endpoint | quote }}
- name: ANALYTIC_POSTHOG_APIKEY
  value: {{ .Values.authgear.analytic.posthog.apiKey | quote }}
{{- end }}
{{- end }}

{{- define "authgear.loggingEnv" -}}
{{- $handlers := list -}}
{{- if .Values.authgear.logging.console.enabled -}}
{{- $handlers = append $handlers "console" -}}
{{- end -}}
{{- if .Values.authgear.logging.otlp.enabled -}}
{{- $handlers = append $handlers "otlp" -}}
{{- end -}}
- name: LOG_LEVEL
  value: {{ .Values.authgear.logLevel | quote }}
- name: LOG_HANDLERS
  value: {{ join "," $handlers | quote }}
{{- if .Values.authgear.logging.console.enabled }}
{{- if .Values.authgear.logging.console.logLevel }}
- name: LOG_HANDLER_CONSOLE_LEVEL
  value: {{ .Values.authgear.logging.console.logLevel | quote }}
{{- end }}
{{- end }}
{{- if .Values.authgear.logging.otlp.enabled }}
{{- if .Values.authgear.logging.otlp.logLevel }}
- name: LOG_HANDLER_OTLP_LEVEL
  value: {{ .Values.authgear.logging.otlp.logLevel | quote }}
{{- end }}
{{- if .Values.authgear.logging.otlp.otlpLogsEndpoint }}
- name: LOG_HANDLER_OTLP_ENDPOINT
  value: {{ .Values.authgear.logging.otlp.otlpLogsEndpoint | quote }}
{{- end }}
{{- end }}
{{- end }}
